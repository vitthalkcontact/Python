#import module
#import module as m
#from module import *
from module import Add,Prod
#print(dir())
#Add(2,3)
#print(dir(m))
print(Add.__doc__)
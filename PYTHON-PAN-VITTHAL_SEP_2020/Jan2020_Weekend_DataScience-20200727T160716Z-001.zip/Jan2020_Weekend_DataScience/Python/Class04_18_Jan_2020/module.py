def Add(a,b):
    """
    This is teh help doc of Add()
    skdhfsd
    fsdhfsdhggs
    
    """
    print(a+b)

def Sub(a,b):
    print(a-b)

def Prod(a,b):
    print(a*b)

def Pow(a,b):
    print(a**b)

def Div(a,b):
    print(a/b)

def __testFunc(a,b):
    print(a+b)

print("I am getting executed from",__name__)
if __name__ == "__main__":
    Add(2,3)
    Prod(10,2)

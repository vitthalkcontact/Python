#import pkg
import pkg.module1 as m1
import pkg.module2.module2 as m2
import pkg.module2.module3.module3 as m3
print(dir(m1))
print(dir(m2))
print(dir(m3))
m1.Add(10,2)
m2.Sub(2,30)
m3.Prod(10,20)
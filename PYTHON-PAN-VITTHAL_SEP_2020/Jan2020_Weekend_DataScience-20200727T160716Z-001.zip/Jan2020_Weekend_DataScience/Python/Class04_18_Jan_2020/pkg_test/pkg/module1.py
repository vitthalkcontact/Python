def Add(a,b):
    """
    This is teh help doc of Add()
    skdhfsd
    fsdhfsdhggs
    
    """
    print(a+b)

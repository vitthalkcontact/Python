
def Prod(a,b):
    print(a*b)

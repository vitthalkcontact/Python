
def Sub(a,b):
    print(a-b)
